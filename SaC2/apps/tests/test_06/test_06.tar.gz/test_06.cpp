#include <sac2.hpp>

int main() {
  sac2::Engine engine;
  engine.run();
  return 0;
}
